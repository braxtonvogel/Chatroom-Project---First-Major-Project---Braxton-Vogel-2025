// ChatServer.java
// ----------------------
// Group-based chat server with a default "Lobby" group.

import java.io.*;
import java.net.*;
import java.util.*;

public class ChatServer {

    // Stores all groups: groupName -> list of clients in that group
    private static Map<String, List<ClientHandler>> groups = new HashMap<>();

    public static void main(String[] args) {
        final int PORT = 1234;

        // Create default group
        groups.put("Lobby", new ArrayList<>());
        System.out.println("Default group 'Lobby' created.");

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New client connected: " + socket);

                ClientHandler clientHandler = new ClientHandler(socket, groups);
                new Thread(clientHandler).start();
            }

        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void broadcastToGroup(String groupName, String message, ClientHandler excludeClient) {
        List<ClientHandler> group = groups.get(groupName);
        if (group == null) return;

        for (ClientHandler client : group) {
            if (client != excludeClient) {
                client.sendMessage(message);
            }
        }
    }

    public static Map<String, List<ClientHandler>> getGroups() {
        return groups;
    }
}
