// ChatClient.java
// ----------------------
// Connects to the chat server and handles user input + incoming messages.

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ChatClient {

    private static final String SERVER_IP = "10.5.0.2";
    private static final int SERVER_PORT = 1234;

    public static void main(String[] args) {
        try {
            Socket socket = new Socket(SERVER_IP, SERVER_PORT);
            System.out.println("Connected to server.");

            BufferedReader inputFromServer = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));

            PrintWriter outputToServer = new PrintWriter(socket.getOutputStream(), true);

            Scanner scanner = new Scanner(System.in);

            // Thread that listens for server messages
            new Thread(() -> {
                try {
                    String msg;
                    while ((msg = inputFromServer.readLine()) != null) {
                        System.out.println(msg);
                    }
                } catch (Exception e) {
                    System.out.println("Disconnected from server.");
                }
            }).start();

            // Sending loop
            while (true) {
                String message = scanner.nextLine();
                if (message.equalsIgnoreCase("/quit")) {
                    outputToServer.println("/quit");
                    socket.close();
                    break;
                }
                outputToServer.println(message);
            }

        } catch (IOException e) {
            System.out.println("Connection error: " + e.getMessage());
        }
    }
}
