First you open the ChatServer file to get the server started, and creates the lobby group.

Then open the ChatClient file, once you do you have the options to choose 1 or 2

1, will allow you to join any pre-existing groups
2, will allow you to create a new group that anyone can join also allowing you to customize the name