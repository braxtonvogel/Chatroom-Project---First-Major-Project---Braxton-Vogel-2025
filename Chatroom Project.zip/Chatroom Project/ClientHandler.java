// ClientHandler.java
// ----------------------
// Handles communication with one client, including group selection.

import java.io.*;
import java.net.*;
import java.util.*;

public class ClientHandler implements Runnable {

    private Socket socket;
    private Map<String, List<ClientHandler>> groups;
    private BufferedReader reader;
    private PrintWriter writer;
    private String clientName;
    private String currentGroup = "Lobby";

    public ClientHandler(Socket socket, Map<String, List<ClientHandler>> groups) {
        this.socket = socket;
        this.groups = groups;
    }

    @Override
    public void run() {
        try {
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            writer = new PrintWriter(socket.getOutputStream(), true);

            writer.println("Enter your name: ");
            clientName = reader.readLine();
            writer.println("Welcome, " + clientName + "!");

            chooseGroup();

            ChatServer.broadcastToGroup(currentGroup, clientName + " has joined!", this);

            String message;
            while ((message = reader.readLine()) != null) {
                if (message.equalsIgnoreCase("/quit")) break;

                ChatServer.broadcastToGroup(currentGroup, clientName + ": " + message, this);
            }

        } catch (IOException e) {
            System.out.println("Client error: " + e.getMessage());
        } finally {
            cleanup();
        }
    }

    private void chooseGroup() throws IOException {
        writer.println("Choose an option:");
        writer.println("1. Join existing group");
        writer.println("2. Create new group");

        String choice = reader.readLine();

        if ("1".equals(choice)) {
            joinExistingGroup();
        } else if ("2".equals(choice)) {
            createNewGroup();
        } else {
            writer.println("Invalid choice. Placing you in Lobby.");
            joinGroup("Lobby");
        }
    }

    private void joinExistingGroup() throws IOException {
        writer.println("Available groups:");
        for (String group : groups.keySet()) writer.println("- " + group);

        writer.println("Enter group name:");
        String name = reader.readLine();

        if (groups.containsKey(name)) joinGroup(name);
        else {
            writer.println("Group not found. Joining Lobby.");
            joinGroup("Lobby");
        }
    }

    private void createNewGroup() throws IOException {
        writer.println("Enter new group name:");
        String name = reader.readLine();

        groups.putIfAbsent(name, new ArrayList<>());
        writer.println("Group '" + name + "' created.");

        joinGroup(name);
    }

    private void joinGroup(String name) {
        groups.get(name).add(this);
        currentGroup = name;
        writer.println("You joined group: " + name);
    }

    private void cleanup() {
        try {
            groups.get(currentGroup).remove(this);
            ChatServer.broadcastToGroup(currentGroup, clientName + " has left.", this);
            socket.close();
        } catch (Exception ignored) {}
    }

    public void sendMessage(String msg) {
        writer.println(msg);
    }
}
